import { nanoid } from 'nanoid';
import { verifyToken } from '../../lib/Token';
import { querys } from '../../lib/DbConnection';
import { NextResponse } from 'next/server';


export async function POST(req) {
    try {
        // Verify the token
        const auth = await verifyToken(req);
        const { decoded } = auth;
        const role = decoded.role;
        const user = decoded.mobile; 

        const data = await req.json();
        const id = nanoid();

        if (role === 'buyer') {
            const query = await querys({
                query: `INSERT INTO products_list (product_id, veg_name, quantity,
                    quantity_available, quantity_sold, unit, price, mobile) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                values: [id, data.veg_name, data.quantity, data.quantity, 0, data.unit,
                        data.price, user]
            });

            if (query.affectedRows > 0) {
                return NextResponse.json({
                    message: 'Product added successfully',
                    status: 200
                }, { status: 200 });
            } else {
                return NextResponse.json({
                    message: 'Insert failed',
                    status: 400
                }, { status: 400 });
            }
        } else {
            return NextResponse.json({
                message: 'Unauthorized',
                status: 403
            }, { status: 403 });
        }

    } catch (error) {
        console.error('Server Error:', error);
        return NextResponse.json({
            message: 'Server Error',
            status: 500
        }, { status: 500 });
    }
}

export async function GET(req) {
    try {
        // Verify the token
        const auth = await verifyToken(req);
        const { decoded } = auth;
        const role = decoded.role;
        const user = decoded.mobile;

        if (role == 'buyer') {
            const query = await querys({
                query: `SELECT * FROM products_list WHERE mobile = ?;`,
                values: [user]
            });

            // Return the inventory data
            return NextResponse.json({
                message: 'Products Listed successfully',
                data: query,
                status: 200
            }, { status: 200 });

        } else {
            return NextResponse.json({
                message: 'Unauthorized',
                status: 403
            }, { status: 403 });
        }
    } catch (error) {
        console.error('Server Error:', error);
        return NextResponse.json({
            message: 'Server Error',
            status: 500
        }, { status: 500 });
    }
}


export async function PUT(req) {
    try {
        const auth = await verifyToken(req);
        const { decoded } = auth;
        const role = decoded.role;
        const userMobile = decoded.mobile;

        const data = await req.json();
        const { veg_name, quantity} = data;

        if (role !== 'buyer') {
            return NextResponse.json({ message: 'Unauthorized', status: 403 }, { status: 403 });
        }

        let remainingQty = quantity;

        const rows = await querys({
            query: `SELECT * FROM products_list 
                    WHERE veg_name = ? AND mobile = ? AND quantity_available > 0 
                    ORDER BY created_at ASC`,
            values: [veg_name, userMobile]
        });

        if (rows.length === 0) {
            return NextResponse.json({ message: 'No available stock to update', status: 404 }, { status: 404 });
        }

        for (const row of rows) {
            if (remainingQty <= 0) break;

            const useQty = Math.min(row.quantity_available, remainingQty);
            const newAvailable = row.quantity_available - useQty;
            const newSold = row.quantity_sold + useQty;

            await querys({
                query: `UPDATE products_list 
                        SET quantity_available = ?, quantity_sold = ? 
                        WHERE id = ?`,
                values: [newAvailable, newSold, row.id]
            });

            remainingQty -= useQty;
        }

        return NextResponse.json({
            message: 'Stock updated successfully',
            status: 200
        }, { status: 200 });

    } catch (error) {
        console.error('Update Error:', error);
        return NextResponse.json({
            message: 'Server Error',
            status: 500
        }, { status: 500 });
    }
}